import { db } from "./client.js";
export async function withTransaction(runner) {
    const client = await db.connect();
    try {
        await client.query("begin");
        const result = await runner(client);
        await client.query("commit");
        return result;
    }
    catch (error) {
        await client.query("rollback");
        throw error;
    }
    finally {
        client.release();
    }
}
export async function q(sql, params = []) {
    return db.query(sql, params);
}
