import { createApp } from "./app.js";
import { env } from "./config/env.js";
import { logger } from "./shared/logger.js";
async function startServer() {
    const app = createApp();
    app.listen(env.port, () => {
        logger.info(`API listening on :${env.port}`);
    });
}
void startServer().catch((error) => {
    logger.error("API startup failed", error);
    process.exit(1);
});
