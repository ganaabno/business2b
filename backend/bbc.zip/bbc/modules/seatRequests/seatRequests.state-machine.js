const allowedTransitions = {
    pending: new Set(["approve", "reject", "cancel_by_admin", "cancel_by_requester"]),
    approved_waiting_deposit: new Set(["deposit_paid", "cancel_expired", "cancel_by_admin", "cancel_by_requester"]),
    confirmed_deposit_paid: new Set(["complete", "cancel_by_admin", "cancel_by_requester"]),
    rejected: new Set([]),
    cancelled_expired: new Set([]),
    cancelled_by_admin: new Set([]),
    cancelled_by_requester: new Set([]),
    completed: new Set([]),
};
export function canTransitionSeatRequest(current, action) {
    return allowedTransitions[current].has(action);
}
