import { withTransaction } from "../../db/transaction.js";
import { env } from "../../config/env.js";
import { badRequest, forbidden, notFound } from "../../shared/http/errors.js";
import { logger } from "../../shared/logger.js";
import { getOrganizationByIdRepo, getPrimaryOrganizationForUserRepo, } from "../organizations/organizations.repo.js";
import { createApprovedSeatRequestFromAccessRepo, } from "../seatRequests/seatRequests.repo.js";
import { ensureGroupPolicyGuard } from "../seatRequests/seatRequests.service.js";
import { approveSeatAccessRequestRepo, consumeSeatAccessRequestRepo, createSeatAccessRequestRepo, expireSeatAccessRequestRepo, getDepartureSeatStatsRepo, getSeatAccessRequestByIdForUpdateRepo, getSeatAccessRequestByIdRepo, getTourSelectionCandidateRepo, listSeatAccessRequestsRepo, rejectSeatAccessRequestRepo, } from "./seatAccessRequests.repo.js";
import { enrichRequesterIdentityRows } from "../auth/requesterIdentity.js";
import { searchToursRepo } from "../tours/tours.repo.js";
function isAdminRole(role) {
    return role === "admin" || role === "manager";
}
function isEmployeeRole(role) {
    return role === "subcontractor" || role === "agent";
}
function canSubmitSeatAccessRequest(user) {
    if (isEmployeeRole(user.role)) {
        return true;
    }
    return user.role === "admin" && Boolean(user.isAdminTestMode);
}
function normalizeText(value) {
    return String(value || "")
        .trim()
        .toLowerCase()
        .replace(/\s+/g, " ");
}
function destinationMatchesApprovedRequest(params) {
    const needle = normalizeText(params.approvedDestination);
    if (!needle) {
        return true;
    }
    const candidates = [
        params.tour.title,
        params.tour.country,
        ...(Array.isArray(params.tour.cities) ? params.tour.cities : []),
    ]
        .map((value) => normalizeText(value))
        .filter((value) => value.length > 0);
    if (candidates.length === 0) {
        return false;
    }
    return candidates.some((value) => value.includes(needle) || needle.includes(value));
}
function toDateMs(value) {
    return new Date(`${value}T00:00:00.000Z`).getTime();
}
const DEFAULT_DECLINE_MESSAGE = "Sorry your request has been declined, try again after a while.";
const DEFAULT_TEST_ORG_ID = "00000000-0000-0000-0000-000000000111";
async function resolveOrganizationIdForSeatAccess(user) {
    if (user.organizationId) {
        return user.organizationId;
    }
    const primaryOrgId = await getPrimaryOrganizationForUserRepo(user.id);
    if (primaryOrgId) {
        return primaryOrgId;
    }
    const canUseDevFallback = !env.isProduction &&
        (isEmployeeRole(user.role) || (user.role === "admin" && Boolean(user.isAdminTestMode)));
    if (!canUseDevFallback) {
        return null;
    }
    const fallbackOrg = await getOrganizationByIdRepo(DEFAULT_TEST_ORG_ID);
    if (!fallbackOrg) {
        return null;
    }
    logger.warn("audit.organization.dev_fallback_applied", {
        userId: user.id,
        role: user.role,
        organizationId: DEFAULT_TEST_ORG_ID,
        context: "seat_access_request",
    });
    return DEFAULT_TEST_ORG_ID;
}
async function enrichSeatAccessRow(row) {
    const [enriched] = await enrichRequesterIdentityRows({
        rows: [row],
        getRequesterAuthUserId: (item) => item.requester_user_id,
    });
    return enriched || row;
}
async function ensureBookableToursExistForApproval(request) {
    const minSeats = Math.max(1, Math.floor(Number(request.planned_seats) || 1));
    const strictMatches = await searchToursRepo({
        from: request.from_date,
        to: request.to_date,
        destination: request.destination,
        minSeats,
    });
    if (strictMatches.length > 0) {
        return;
    }
    const broadMatches = await searchToursRepo({
        from: request.from_date,
        to: request.to_date,
        minSeats,
    });
    if (broadMatches.length === 0) {
        throw badRequest("Cannot approve request: no tours are currently available for the selected date range and seat count");
    }
    throw badRequest(`Cannot approve request: no tours currently match destination \"${request.destination}\" for ${request.from_date} to ${request.to_date}. Ask requester to submit a destination that exists in current inventory.`);
}
export async function submitSeatAccessRequestService(user, input) {
    if (!canSubmitSeatAccessRequest(user)) {
        throw forbidden("Only subcontractor or agent can submit seat access requests (admin can submit in Admin Test Mode)");
    }
    const requesterRole = isEmployeeRole(user.role)
        ? user.role
        : "subcontractor";
    const resolvedOrganizationId = await resolveOrganizationIdForSeatAccess(user);
    if (!resolvedOrganizationId) {
        throw badRequest("User must belong to an organization (for Admin Test Mode set a test Organization UUID)");
    }
    if (!isEmployeeRole(user.role)) {
        logger.warn("audit.seat_access_request.admin_test.submit", {
            actorId: user.actorId || user.id,
            actorRole: user.actorRole || user.role,
            effectiveRole: user.role,
            requesterRole,
            organizationId: resolvedOrganizationId,
        });
    }
    try {
        const id = await withTransaction(async (client) => {
            return createSeatAccessRequestRepo(client, {
                requesterUserId: user.id,
                organizationId: resolvedOrganizationId,
                requesterRole,
                fromDate: input.fromDate,
                toDate: input.toDate,
                destination: input.destination,
                note: input.note,
                plannedSeats: input.plannedSeats,
            });
        });
        if (!id) {
            throw new Error("Seat access request insert returned empty id");
        }
        const row = await getSeatAccessRequestByIdRepo(id);
        if (!row) {
            throw new Error("Seat access request created but could not be loaded");
        }
        const enrichedRow = await enrichSeatAccessRow(row);
        logger.info("audit.seat_access_request.submitted", {
            seatAccessRequestId: enrichedRow.id,
            userId: user.id,
            organizationId: enrichedRow.organization_id,
            destination: enrichedRow.destination,
            fromDate: enrichedRow.from_date,
            toDate: enrichedRow.to_date,
        });
        return enrichedRow;
    }
    catch (error) {
        const dbError = error;
        if (dbError.code === "23505") {
            throw badRequest("A pending request already exists for this destination and date range");
        }
        throw error;
    }
}
export async function listSeatAccessRequestsService(user, filters) {
    const rows = await listSeatAccessRequestsRepo({
        userId: isAdminRole(user.role) ? undefined : user.id,
        status: filters.status,
        destination: filters.destination,
    });
    return enrichRequesterIdentityRows({
        rows,
        getRequesterAuthUserId: (item) => item.requester_user_id,
    });
}
export async function approveSeatAccessRequestService(user, id, reason) {
    if (!isAdminRole(user.role)) {
        throw forbidden("Only admin or manager can approve seat access requests");
    }
    const preflight = await getSeatAccessRequestByIdRepo(id);
    if (!preflight) {
        throw notFound("Seat access request not found");
    }
    if (preflight.status !== "pending") {
        throw badRequest("Only pending seat access requests can be approved");
    }
    await ensureBookableToursExistForApproval(preflight);
    const row = await withTransaction(async (client) => {
        const request = await getSeatAccessRequestByIdForUpdateRepo(client, id);
        if (!request) {
            throw notFound("Seat access request not found");
        }
        if (request.status !== "pending") {
            throw badRequest("Only pending seat access requests can be approved");
        }
        await approveSeatAccessRequestRepo(client, {
            id: request.id,
            reviewedBy: user.id,
            decisionReason: reason,
        });
        const updated = await getSeatAccessRequestByIdRepo(request.id, client);
        if (!updated) {
            throw new Error("Seat access request approved but could not be loaded");
        }
        return updated;
    });
    logger.info("audit.seat_access_request.approved", {
        seatAccessRequestId: row.id,
        userId: row.requester_user_id,
        reviewedBy: user.id,
        organizationId: row.organization_id,
    });
    return enrichSeatAccessRow(row);
}
export async function rejectSeatAccessRequestService(user, id, reason) {
    if (!isAdminRole(user.role)) {
        throw forbidden("Only admin or manager can reject seat access requests");
    }
    const row = await withTransaction(async (client) => {
        const request = await getSeatAccessRequestByIdForUpdateRepo(client, id);
        if (!request) {
            throw notFound("Seat access request not found");
        }
        if (request.status !== "pending") {
            throw badRequest("Only pending seat access requests can be rejected");
        }
        await rejectSeatAccessRequestRepo(client, {
            id: request.id,
            reviewedBy: user.id,
            decisionReason: reason || DEFAULT_DECLINE_MESSAGE,
        });
        const updated = await getSeatAccessRequestByIdRepo(request.id, client);
        if (!updated) {
            throw new Error("Seat access request rejected but could not be loaded");
        }
        return updated;
    });
    logger.info("audit.seat_access_request.rejected", {
        seatAccessRequestId: row.id,
        userId: row.requester_user_id,
        reviewedBy: user.id,
        organizationId: row.organization_id,
    });
    return enrichSeatAccessRow(row);
}
export async function selectTourFromSeatAccessRequestService(user, accessRequestId, input) {
    if (!isEmployeeRole(user.role)) {
        throw forbidden("Only subcontractor or agent can select tours for approved requests");
    }
    return withTransaction(async (client) => {
        const accessRequest = await getSeatAccessRequestByIdForUpdateRepo(client, accessRequestId);
        if (!accessRequest) {
            throw notFound("Seat access request not found");
        }
        if (accessRequest.requester_user_id !== user.id) {
            throw forbidden("Cannot use another user's seat access request");
        }
        if (accessRequest.status !== "approved") {
            throw badRequest("Seat access request must be approved before selecting tour/seats");
        }
        if (accessRequest.seat_request_id) {
            throw badRequest("This seat access request has already been used");
        }
        if (accessRequest.expires_at && new Date(accessRequest.expires_at).getTime() < Date.now()) {
            await expireSeatAccessRequestRepo(client, accessRequest.id);
            throw badRequest("This approval has expired. Please submit a new request");
        }
        const fromMs = toDateMs(accessRequest.from_date);
        const toMs = toDateMs(accessRequest.to_date);
        const travelMs = toDateMs(input.travelDate);
        if (travelMs < fromMs || travelMs > toMs) {
            throw badRequest("Selected travel date is outside approved date range");
        }
        const tour = await getTourSelectionCandidateRepo(client, {
            tourId: input.tourId,
            travelDate: input.travelDate,
        });
        if (!tour) {
            throw badRequest("Tour is not available on selected departure date");
        }
        if (!destinationMatchesApprovedRequest({
            approvedDestination: accessRequest.destination,
            tour,
        })) {
            throw badRequest("Selected tour does not match approved destination");
        }
        const stats = await getDepartureSeatStatsRepo(client, {
            tourId: input.tourId,
            travelDate: input.travelDate,
        });
        const statsRemaining = Number(stats?.remaining ?? 0);
        const statsCapacity = Number(stats?.capacity ?? 0);
        const statsBooked = Number(stats?.booked ?? 0);
        const candidateRemaining = Number(tour.available_seats ?? 0);
        let remaining = statsRemaining > 0 || candidateRemaining <= 0 ? statsRemaining : candidateRemaining;
        if (remaining <= 0 && statsBooked === 0 && statsCapacity > 0) {
            remaining = statsCapacity;
        }
        if (input.requestedSeats > remaining) {
            throw badRequest(`Don't have enough seats. Remaining seats: ${remaining}`);
        }
        await ensureGroupPolicyGuard({
            user,
            organizationId: accessRequest.organization_id,
            requestedSeats: input.requestedSeats,
        });
        const seatRequest = await createApprovedSeatRequestFromAccessRepo(client, {
            requesterUserId: accessRequest.requester_user_id,
            organizationId: accessRequest.organization_id,
            requesterRole: accessRequest.requester_role,
            tourId: input.tourId,
            destination: tour.title,
            travelDate: input.travelDate,
            requestedSeats: input.requestedSeats,
            unitPriceMnt: Number(tour.base_price || 0),
            accessRequestId: accessRequest.id,
        });
        await client.query(`select public.fn_generate_payment_milestones($1::uuid)`, [seatRequest.id]);
        await consumeSeatAccessRequestRepo(client, {
            id: accessRequest.id,
            seatRequestId: seatRequest.id,
        });
        await client.query(`
      insert into public.integration_outbox (aggregate_type, aggregate_id, event_type, payload)
      values
        (
          'seat_request',
          $1::text,
          'seat_request.created',
          jsonb_build_object('seatRequestId', $1::text, 'viaAccessRequest', $2::text)
        ),
        (
          'seat_request',
          $1::text,
          'seat_request.approved',
          jsonb_build_object(
            'seatRequestId',
            $1::text,
            'autoApproved',
            true,
            'viaAccessRequest',
            $2::text
          )
        )
      `, [seatRequest.id, accessRequest.id]);
        logger.info("audit.seat_access_request.consumed", {
            seatAccessRequestId: accessRequest.id,
            seatRequestId: seatRequest.id,
            userId: accessRequest.requester_user_id,
            organizationId: accessRequest.organization_id,
            requestedSeats: input.requestedSeats,
            seatRequestStatus: seatRequest.status,
        });
        return seatRequest;
    });
}
