import { q } from "../../db/transaction.js";
const BASE_SELECT = `
  select
    sar.id::text,
    sar.requester_user_id::text,
    sar.organization_id::text,
    o.name as organization_name,
    sar.requester_role::text as requester_role,
    sar.from_date::text,
    sar.to_date::text,
    sar.destination,
    sar.planned_seats,
    sar.note,
    sar.status::text as status,
    sar.decision_reason,
    sar.reviewed_by::text,
    reviewer.email as reviewed_by_email,
    sar.reviewed_at,
    sar.approved_at,
    sar.expires_at,
    sar.consumed_at,
    sar.seat_request_id::text,
    sar.created_at,
    sar.updated_at,
    coalesce(
      nullif(to_jsonb(requester) ->> 'first_name', ''),
      nullif(to_jsonb(requester) ->> 'firstname', '')
    ) as requester_first_name,
    coalesce(
      nullif(to_jsonb(requester) ->> 'last_name', ''),
      nullif(to_jsonb(requester) ->> 'lastname', '')
    ) as requester_last_name,
    coalesce(
      nullif(to_jsonb(requester) ->> 'username', ''),
      nullif(to_jsonb(requester) ->> 'user_name', ''),
      nullif(to_jsonb(requester) ->> 'name', '')
    ) as requester_username,
    coalesce(
      nullif(requester.email, ''),
      nullif(to_jsonb(requester) ->> 'email', '')
    ) as requester_email
  from public.seat_access_requests sar
  left join public.organizations o on o.id = sar.organization_id
  left join lateral (
    select u.*
    from public.users u
    where u.id::text = sar.requester_user_id::text
       or coalesce(
         nullif(to_jsonb(u) ->> 'auth_user_id', ''),
         nullif(to_jsonb(u) ->> 'userid', '')
       ) = sar.requester_user_id::text
    limit 1
  ) requester on true
  left join public.users reviewer on reviewer.id::text = sar.reviewed_by::text
`;
async function runQuery(sql, params, client) {
    if (client) {
        return client.query(sql, params);
    }
    return q(sql, params);
}
export async function createSeatAccessRequestRepo(client, params) {
    const { rows } = await client.query(`
    insert into public.seat_access_requests (
      requester_user_id,
      organization_id,
      requester_role,
      from_date,
      to_date,
      destination,
      planned_seats,
      note,
      status
    )
    values ($1::uuid, $2::uuid, $3::public.app_role, $4::date, $5::date, $6, $7, $8, 'pending')
    returning id::text
    `, [
        params.requesterUserId,
        params.organizationId,
        params.requesterRole,
        params.fromDate,
        params.toDate,
        params.destination,
        params.plannedSeats,
        params.note,
    ]);
    return rows[0]?.id || null;
}
export async function listSeatAccessRequestsRepo(filters, client) {
    const params = [];
    const conditions = [];
    if (filters.userId) {
        params.push(filters.userId);
        conditions.push(`sar.requester_user_id = $${params.length}::uuid`);
    }
    if (filters.status) {
        params.push(filters.status);
        conditions.push(`sar.status::text = $${params.length}`);
    }
    if (filters.destination) {
        params.push(filters.destination);
        conditions.push(`sar.destination ilike ('%' || $${params.length} || '%')`);
    }
    const whereSql = conditions.length > 0 ? `where ${conditions.join(" and ")}` : "";
    const limit = Math.max(1, Math.min(filters.limit ?? 300, 500));
    params.push(limit);
    const { rows } = await runQuery(`
    ${BASE_SELECT}
    ${whereSql}
    order by sar.created_at desc
    limit $${params.length}
    `, params, client);
    return rows;
}
export async function getSeatAccessRequestByIdRepo(id, client) {
    const { rows } = await runQuery(`
    ${BASE_SELECT}
    where sar.id = $1::uuid
    limit 1
    `, [id], client);
    return rows[0] || null;
}
export async function getSeatAccessRequestByIdForUpdateRepo(client, id) {
    const { rows } = await client.query(`
    select
      id::text,
      requester_user_id::text,
      organization_id::text,
      requester_role::text as requester_role,
      from_date::text,
      to_date::text,
      destination,
      planned_seats,
      status::text as status,
      expires_at,
      seat_request_id::text
    from public.seat_access_requests
    where id = $1::uuid
    for update
    `, [id]);
    return rows[0] || null;
}
export async function approveSeatAccessRequestRepo(client, params) {
    await client.query(`
    update public.seat_access_requests
    set
      status = 'approved',
      reviewed_by = $2::uuid,
      reviewed_at = now(),
      approved_at = now(),
      decision_reason = $3,
      expires_at = (to_date::timestamptz + interval '1 day'),
      updated_at = now()
    where id = $1::uuid
    `, [params.id, params.reviewedBy, params.decisionReason]);
}
export async function rejectSeatAccessRequestRepo(client, params) {
    await client.query(`
    update public.seat_access_requests
    set
      status = 'rejected',
      reviewed_by = $2::uuid,
      reviewed_at = now(),
      decision_reason = $3,
      updated_at = now()
    where id = $1::uuid
    `, [params.id, params.reviewedBy, params.decisionReason]);
}
export async function expireSeatAccessRequestRepo(client, id) {
    await client.query(`
    update public.seat_access_requests
    set
      status = 'expired',
      updated_at = now()
    where id = $1::uuid
    `, [id]);
}
export async function consumeSeatAccessRequestRepo(client, params) {
    await client.query(`
    update public.seat_access_requests
    set
      status = 'consumed',
      consumed_at = now(),
      seat_request_id = $2::uuid,
      updated_at = now()
    where id = $1::uuid
    `, [params.id, params.seatRequestId]);
}
export async function getTourSelectionCandidateRepo(client, params) {
    const { rows } = await client.query(`
    with departure_dates as (
      select
        t.id::text as tour_id,
        unnest(
          case
            when pg_typeof(t.dates)::text = 'text[]' and cardinality(t.dates) > 0 then t.dates
            when t.departuredate is not null then array[t.departuredate::text]
            else array[$2::text]
          end
        )::date as departure_date
      from public.tours t
      where t.id::text = $1::text
    )
    select
      t.id::text,
      t.title,
      nullif(btrim(t.country), '') as country,
      coalesce(t.cities, array[]::text[]) as cities,
      coalesce(t.base_price, 0) as base_price,
      (
        case
          when coalesce(stats.remaining, 0) > 0 then coalesce(stats.remaining, 0)
          when coalesce(t.available_seats, 0) > 0 then coalesce(t.available_seats, 0)
          when d.departure_date is null
               and t.departuredate is null
               and cardinality(coalesce(t.dates, array[]::text[])) = 0
            then coalesce(t.seats, 0)
          else coalesce(stats.remaining, t.available_seats, 0)
        end
      ) as available_seats
    from public.tours t
    join departure_dates d on d.tour_id = t.id::text
    left join lateral public.get_departure_seats(
      t.id::text,
      coalesce(d.departure_date::text, $2::text)
    ) stats on true
    where t.id::text = $1::text
      and d.departure_date = $2::date
    limit 1
    `, [params.tourId, params.travelDate]);
    return rows[0] || null;
}
export async function getDepartureSeatStatsRepo(client, params) {
    const { rows } = await client.query(`
    select capacity, booked, remaining
    from public.get_departure_seats($1, $2)
    `, [params.tourId, params.travelDate]);
    return rows[0] || null;
}
