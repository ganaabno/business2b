import { forbidden, notFound } from "../../shared/http/errors.js";
import { addMemberRepo, createOrganizationRepo, getOrganizationByIdRepo, getPrimaryOrganizationForUserRepo, } from "./organizations.repo.js";
export async function createOrganizationService(user, input) {
    const org = await createOrganizationRepo({ ...input, createdBy: user.id });
    await addMemberRepo({
        organizationId: org.id,
        userId: user.id,
        role: user.role,
        isPrimary: true,
    });
    return org;
}
export async function getOrganizationService(user, orgId) {
    const org = await getOrganizationByIdRepo(orgId);
    if (!org)
        throw notFound("Organization not found");
    if (user.role === "admin" || user.role === "manager") {
        return org;
    }
    const primaryOrgId = await getPrimaryOrganizationForUserRepo(user.id);
    if (primaryOrgId !== orgId) {
        throw forbidden("Cannot access this organization");
    }
    return org;
}
export async function addMemberService(user, orgId, input) {
    const org = await getOrganizationByIdRepo(orgId);
    if (!org)
        throw notFound("Organization not found");
    if (!(user.role === "admin" || user.role === "manager")) {
        const primaryOrgId = await getPrimaryOrganizationForUserRepo(user.id);
        if (primaryOrgId !== orgId) {
            throw forbidden("Only organization owners can add members");
        }
    }
    await addMemberRepo({
        organizationId: orgId,
        userId: input.userId,
        role: input.role,
        isPrimary: input.isPrimary,
    });
}
