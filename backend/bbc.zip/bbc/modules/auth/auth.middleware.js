import { createClient } from "@supabase/supabase-js";
import { env } from "../../config/env.js";
import { q } from "../../db/transaction.js";
import { badRequest, forbidden, unauthorized, } from "../../shared/http/errors.js";
import { logger } from "../../shared/logger.js";
const supabase = createClient(env.supabaseUrl, env.supabaseAnonKey, {
    auth: { persistSession: false },
});
const AUTH_LOOKUP_CACHE_TTL_MS = env.isProduction ? 30_000 : 10_000;
const AUTH_LOOKUP_CACHE_MAX_ITEMS = 2000;
const userPayloadByIdCache = new Map();
const userPayloadByAuthUserIdCache = new Map();
const userPayloadByEmailCache = new Map();
const primaryOrgByUserIdCache = new Map();
let usersColumnSetCache = null;
function readCacheValue(cache, key) {
    const entry = cache.get(key);
    if (!entry) {
        return undefined;
    }
    if (entry.expiresAt <= Date.now()) {
        cache.delete(key);
        return undefined;
    }
    return entry.value;
}
function writeCacheValue(cache, key, value) {
    cache.set(key, {
        value,
        expiresAt: Date.now() + AUTH_LOOKUP_CACHE_TTL_MS,
    });
    if (cache.size <= AUTH_LOOKUP_CACHE_MAX_ITEMS) {
        return;
    }
    const now = Date.now();
    for (const [cacheKey, cacheEntry] of cache.entries()) {
        if (cacheEntry.expiresAt <= now) {
            cache.delete(cacheKey);
        }
    }
    while (cache.size > AUTH_LOOKUP_CACHE_MAX_ITEMS) {
        const oldestKey = cache.keys().next().value;
        if (!oldestKey) {
            break;
        }
        cache.delete(oldestKey);
    }
}
function normalizeRole(value) {
    const role = String(value ?? "").toLowerCase();
    switch (role) {
        case "admin":
            return "admin";
        case "manager":
            return "manager";
        case "subcontractor":
        case "user":
            return "subcontractor";
        case "agent":
        case "provider":
            return "agent";
        case "superadmin":
            return "admin";
        default:
            return "subcontractor";
    }
}
function resolveDevelopmentFallbackRole(user) {
    const appMetadata = user.app_metadata || {};
    const userMetadata = user.user_metadata || {};
    return normalizeRole(appMetadata.role_v2 ||
        appMetadata.workspace_role ||
        appMetadata.role ||
        userMetadata.role_v2 ||
        userMetadata.workspace_role ||
        userMetadata.role ||
        "subcontractor");
}
function resolveLookupEmail(user) {
    const candidates = [
        user.email,
        user.user_metadata?.email,
        user.app_metadata?.email,
        ...(Array.isArray(user.identities)
            ? user.identities.map((identity) => identity?.identity_data?.email)
            : []),
    ];
    for (const candidate of candidates) {
        const normalized = normalizeEmail(candidate);
        if (normalized) {
            return normalized;
        }
    }
    return "";
}
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
function isMissingColumnError(error) {
    const pgError = error;
    const message = String(pgError?.message || "").toLowerCase();
    return pgError?.code === "42703" || message.includes("column");
}
async function getUsersColumnSet() {
    const cached = usersColumnSetCache;
    if (cached && cached.expiresAt > Date.now()) {
        return cached.value;
    }
    const { rows } = await q(`
    select lower(column_name) as column_name
    from information_schema.columns
    where table_schema = 'public'
      and table_name = 'users'
    `, []);
    const columnSet = new Set(rows.map((row) => row.column_name));
    usersColumnSetCache = {
        value: columnSet,
        expiresAt: Date.now() + AUTH_LOOKUP_CACHE_TTL_MS,
    };
    return columnSet;
}
function normalizeKey(value) {
    return String(value || "").trim();
}
function normalizeEmail(value) {
    return String(value || "")
        .trim()
        .toLowerCase();
}
function cacheUserPayload(payload, aliases) {
    const idKeys = new Set([
        normalizeKey(payload.id),
        ...(aliases?.idAliases || []).map((value) => normalizeKey(value)),
    ]);
    const authUserIdKeys = new Set([
        normalizeKey(payload.auth_user_id),
        ...(aliases?.authUserIdAliases || []).map((value) => normalizeKey(value)),
    ]);
    const emailKeys = new Set([
        normalizeEmail(payload.email),
        ...(aliases?.emailAliases || []).map((value) => normalizeEmail(value)),
    ]);
    for (const key of idKeys) {
        if (key) {
            writeCacheValue(userPayloadByIdCache, key, payload);
        }
    }
    for (const key of authUserIdKeys) {
        if (!key) {
            continue;
        }
        writeCacheValue(userPayloadByAuthUserIdCache, key, payload);
        writeCacheValue(userPayloadByIdCache, key, payload);
    }
    for (const key of emailKeys) {
        if (key) {
            writeCacheValue(userPayloadByEmailCache, key, payload);
        }
    }
}
async function getUserPayloadById(userId) {
    const normalizedUserId = normalizeKey(userId);
    if (!normalizedUserId) {
        return null;
    }
    const cached = readCacheValue(userPayloadByIdCache, normalizedUserId);
    if (cached !== undefined) {
        return cached;
    }
    const { rows } = await q(`
    select to_jsonb(u) as payload
    from public.users u
    where u.id::text = $1::text
    limit 1
    `, [normalizedUserId]);
    const payload = rows[0]?.payload || null;
    if (!payload) {
        return null;
    }
    cacheUserPayload(payload, { idAliases: [normalizedUserId] });
    return payload;
}
async function getUserPayloadByAuthUserId(authUserId) {
    const normalizedAuthUserId = normalizeKey(authUserId);
    if (!normalizedAuthUserId) {
        return null;
    }
    const cached = readCacheValue(userPayloadByAuthUserIdCache, normalizedAuthUserId);
    if (cached !== undefined) {
        return cached;
    }
    const usersColumns = await getUsersColumnSet();
    if (!usersColumns.has("auth_user_id")) {
        return null;
    }
    try {
        const { rows } = await q(`
      select to_jsonb(u) as payload
      from public.users u
      where u.auth_user_id::text = $1::text
      limit 1
      `, [normalizedAuthUserId]);
        const payload = rows[0]?.payload || null;
        if (!payload) {
            return null;
        }
        cacheUserPayload(payload, {
            authUserIdAliases: [normalizedAuthUserId],
            idAliases: [normalizedAuthUserId],
        });
        return payload;
    }
    catch (error) {
        if (isMissingColumnError(error)) {
            return null;
        }
        throw error;
    }
}
async function getUserPayloadByEmail(email) {
    const normalized = normalizeEmail(email);
    if (!normalized) {
        return null;
    }
    const cached = readCacheValue(userPayloadByEmailCache, normalized);
    if (cached !== undefined) {
        return cached;
    }
    const { rows } = await q(`
    select to_jsonb(u) as payload
    from public.users u
    where lower(u.email) = $1
    limit 1
    `, [normalized]);
    const payload = rows[0]?.payload || null;
    if (!payload) {
        return null;
    }
    cacheUserPayload(payload, { emailAliases: [normalized] });
    return payload;
}
async function getPrimaryOrganizationId(userId) {
    const normalizedUserId = String(userId || "").trim();
    if (!normalizedUserId) {
        return null;
    }
    const cached = readCacheValue(primaryOrgByUserIdCache, normalizedUserId);
    if (cached !== undefined) {
        return cached;
    }
    try {
        const { rows } = await q(`
      select om.organization_id::text as organization_id
      from public.organization_members om
      where om.user_id::text = $1::text and om.is_primary = true
      limit 1
      `, [normalizedUserId]);
        const organizationId = rows[0]?.organization_id || null;
        writeCacheValue(primaryOrgByUserIdCache, normalizedUserId, organizationId);
        return organizationId;
    }
    catch (error) {
        logger.warn("auth.requireAuth organization lookup failed; continuing without org context", {
            error,
        });
        return null;
    }
}
function parseActingRole(value) {
    const role = String(value || "")
        .trim()
        .toLowerCase();
    switch (role) {
        case "admin":
            return "admin";
        case "manager":
            return "manager";
        case "subcontractor":
        case "user":
            return "subcontractor";
        case "agent":
        case "provider":
            return "agent";
        default:
            throw badRequest("x-acting-role must be one of: admin, manager, subcontractor|user, agent|provider");
    }
}
function normalizeIp(ip) {
    const value = ip.trim();
    if (value.startsWith("::ffff:")) {
        return value.slice(7);
    }
    return value;
}
function isIpAllowlisted(ip) {
    if (env.b2bAdminTestModeIpAllowlist.length === 0) {
        return true;
    }
    const normalizedIp = normalizeIp(ip);
    return env.b2bAdminTestModeIpAllowlist.some((candidate) => normalizeIp(candidate) === normalizedIp);
}
export async function requireAuth(req, _res, next) {
    try {
        const header = req.headers.authorization || "";
        const token = header.startsWith("Bearer ") ? header.slice(7) : "";
        if (!token) {
            throw unauthorized("Missing bearer token");
        }
        const { data, error } = await supabase.auth.getUser(token);
        if (error || !data.user) {
            throw unauthorized("Invalid token");
        }
        const lookupEmail = resolveLookupEmail(data.user);
        const userId = data.user.id;
        let payload = await getUserPayloadById(userId);
        if (!payload) {
            const payloadByAuthUserId = await getUserPayloadByAuthUserId(userId);
            if (payloadByAuthUserId) {
                payload = payloadByAuthUserId;
                logger.warn("auth.requireAuth matched user profile by auth_user_id fallback", {
                    userId,
                    email: lookupEmail || null,
                    profileUserId: String(payloadByAuthUserId.id || "").trim() || null,
                });
            }
        }
        if (!payload && lookupEmail) {
            const payloadByEmail = await getUserPayloadByEmail(lookupEmail);
            if (payloadByEmail) {
                payload = payloadByEmail;
                cacheUserPayload(payloadByEmail, {
                    idAliases: [userId],
                    authUserIdAliases: [userId],
                    emailAliases: [lookupEmail],
                });
                logger.warn("auth.requireAuth matched user profile by email fallback", {
                    userId,
                    email: lookupEmail,
                });
            }
        }
        if (!payload) {
            if (!env.isProduction) {
                const fallbackRole = resolveDevelopmentFallbackRole(data.user);
                logger.warn("auth.requireAuth profile missing; using development fallback", {
                    userId,
                    email: lookupEmail || null,
                    fallbackRole,
                });
                payload = {
                    id: userId,
                    email: lookupEmail || null,
                    role: fallbackRole,
                    role_v2: fallbackRole,
                    workspace_role: fallbackRole,
                };
            }
            else {
                throw unauthorized("User profile not found");
            }
        }
        const roleV2 = String(payload.role_v2 || "").trim();
        const legacyRole = String(payload.role || "").trim();
        const profileUserId = String(payload.id || userId).trim() || userId;
        const primaryOrganizationId = await getPrimaryOrganizationId(profileUserId);
        const actorRole = normalizeRole(roleV2 || legacyRole);
        let effectiveRole = actorRole;
        let effectiveOrganizationId = primaryOrganizationId;
        let adminTestModeActive = false;
        const actingRoleHeader = typeof req.headers["x-acting-role"] === "string"
            ? req.headers["x-acting-role"]
            : "";
        const actingOrganizationHeader = typeof req.headers["x-acting-org-id"] === "string"
            ? req.headers["x-acting-org-id"]
            : "";
        const hasOverrideHeader = actingRoleHeader.trim().length > 0 ||
            actingOrganizationHeader.trim().length > 0;
        if (hasOverrideHeader) {
            if (!env.b2bAdminTestModeEnabled || env.isProduction) {
                throw forbidden("Admin test mode is disabled");
            }
            if (!(actorRole === "admin" || actorRole === "manager")) {
                throw forbidden("Only admin or manager can use admin test mode");
            }
            if (!isIpAllowlisted(req.ip || "")) {
                throw forbidden("Admin test mode is not allowed from this IP");
            }
            if (actingRoleHeader.trim().length > 0) {
                effectiveRole = parseActingRole(actingRoleHeader);
            }
            if (actingOrganizationHeader.trim().length > 0) {
                const organizationId = actingOrganizationHeader.trim();
                if (!UUID_PATTERN.test(organizationId)) {
                    throw badRequest("x-acting-org-id must be a valid UUID");
                }
                effectiveOrganizationId = organizationId;
            }
            adminTestModeActive = true;
            logger.warn("audit.auth.admin_test_mode.override", {
                actorUserId: userId,
                actorRole,
                effectiveRole,
                effectiveOrganizationId,
                method: req.method,
                path: req.originalUrl,
                ip: req.ip,
            });
        }
        req.user = {
            id: userId,
            role: effectiveRole,
            organizationId: effectiveOrganizationId,
            actorId: userId,
            actorRole,
            isAdminTestMode: adminTestModeActive,
        };
        next();
    }
    catch (error) {
        next(error);
    }
}
