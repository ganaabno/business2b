import { asyncHandler } from "../../shared/http/asyncHandler.js";
import { approveBindingRequestService, listBindingRequestsService, rejectBindingRequestService, submitBindingRequestService, } from "./bindingRequests.service.js";
import { parseBindingDecisionInput, parseBindingListFilters, parseCreateBindingRequestInput, } from "./bindingRequests.schema.js";
const getParam = (value) => Array.isArray(value) ? value[0] : value || "";
export const submitBindingRequestController = asyncHandler(async (req, res) => {
    const input = parseCreateBindingRequestInput(req.body);
    const data = await submitBindingRequestService(req.user, input);
    res.status(201).json({ data });
});
export const listBindingRequestsController = asyncHandler(async (req, res) => {
    const filters = parseBindingListFilters(req.query);
    const data = await listBindingRequestsService(req.user, filters);
    res.json({ data });
});
export const approveBindingRequestController = asyncHandler(async (req, res) => {
    const { reason } = parseBindingDecisionInput(req.body);
    const data = await approveBindingRequestService(req.user, getParam(req.params.id), reason);
    res.json({ data });
});
export const rejectBindingRequestController = asyncHandler(async (req, res) => {
    const { reason } = parseBindingDecisionInput(req.body);
    const data = await rejectBindingRequestService(req.user, getParam(req.params.id), reason);
    res.json({ data });
});
