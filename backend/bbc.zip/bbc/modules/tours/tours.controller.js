import { asyncHandler } from "../../shared/http/asyncHandler.js";
import { parseEnsureGlobalTourBookableInput, parseListTourDestinationsFilters, parsePushGlobalTourInput, parseSyncGlobalPriceRowCanonicalInput, parseSyncGlobalPriceRowInput, parseSyncGlobalToursInput, } from "./tours.schema.js";
import { ensureGlobalTourBookableService, getGlobalOrdersProxyPayloadService, getGlobalToursProxyPayloadService, getGlobalToursSyncStatusService, listTourDestinationsService, pushGlobalTourService, searchToursService, syncGlobalPriceRowCanonicalService, syncGlobalPriceRowService, syncGlobalToursService, } from "./tours.service.js";
export const listTourDestinationsController = asyncHandler(async (req, res) => {
    const filters = parseListTourDestinationsFilters(req.query);
    const data = await listTourDestinationsService(filters);
    res.json({ data });
});
export const searchToursController = asyncHandler(async (req, res) => {
    const data = await searchToursService(req.user, req.query);
    res.json({ data });
});
export const syncGlobalToursController = asyncHandler(async (req, res) => {
    const input = parseSyncGlobalToursInput(req.body);
    const data = await syncGlobalToursService(req.user, input);
    res.json({ data });
});
export const getGlobalToursSyncStatusController = asyncHandler(async (_req, res) => {
    const data = await getGlobalToursSyncStatusService();
    res.json({ data });
});
export const getGlobalToursProxyController = asyncHandler(async (req, res) => {
    const data = await getGlobalToursProxyPayloadService(req.user);
    res.json({ data });
});
export const getGlobalOrdersProxyController = asyncHandler(async (req, res) => {
    const data = await getGlobalOrdersProxyPayloadService(req.user);
    res.json({ data });
});
export const pushGlobalTourController = asyncHandler(async (req, res) => {
    const input = parsePushGlobalTourInput(req.body);
    const data = await pushGlobalTourService(req.user, input);
    res.json({ data });
});
export const syncGlobalPriceRowController = asyncHandler(async (req, res) => {
    const input = parseSyncGlobalPriceRowInput(req.body);
    const data = await syncGlobalPriceRowService(req.user, input);
    res.json({ data });
});
export const syncGlobalPriceRowCanonicalController = asyncHandler(async (req, res) => {
    const input = parseSyncGlobalPriceRowCanonicalInput(req.body);
    const data = await syncGlobalPriceRowCanonicalService(req.user, input);
    res.json({ data });
});
export const ensureGlobalTourBookableController = asyncHandler(async (req, res) => {
    const input = parseEnsureGlobalTourBookableInput(req.body);
    const data = await ensureGlobalTourBookableService(req.user, input);
    res.json({ data });
});
