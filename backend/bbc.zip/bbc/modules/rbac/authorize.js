import { can } from "./policy.js";
export function authorize(action) {
    return (req, res, next) => {
        const user = req.user;
        if (!user) {
            return res.status(401).json({ error: "Unauthorized" });
        }
        if (!can(user.role, action)) {
            return res.status(403).json({ error: "Forbidden" });
        }
        return next();
    };
}
