import test from "node:test";
import assert from "node:assert/strict";
import { can } from "./policy.js";
test("tours sync permission is restricted to admin and manager", () => {
    assert.equal(can("admin", "tours:sync"), true);
    assert.equal(can("manager", "tours:sync"), true);
    assert.equal(can("subcontractor", "tours:sync"), false);
    assert.equal(can("agent", "tours:sync"), false);
});
test("subcontractor and agent keep seat request create permission", () => {
    assert.equal(can("subcontractor", "seatRequest:create"), true);
    assert.equal(can("agent", "seatRequest:create"), true);
    assert.equal(can("manager", "seatRequest:create"), false);
});
