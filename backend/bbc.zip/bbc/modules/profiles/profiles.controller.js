import { asyncHandler } from "../../shared/http/asyncHandler.js";
import { getProfileOverviewService } from "./profiles.service.js";
export const getProfileOverviewController = asyncHandler(async (req, res) => {
    const data = await getProfileOverviewService(req.user);
    res.json({ data });
});
