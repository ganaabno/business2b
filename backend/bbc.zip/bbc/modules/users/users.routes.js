import { Router } from "express";
import { authorize } from "../rbac/authorize.js";
import { approvePendingUserController, changeUserRoleController, declinePendingUserController, listPendingUsersController, listUsersController, } from "./users.controller.js";
export const usersRouter = Router();
usersRouter.get("/", authorize("users:view:all"), listUsersController);
usersRouter.get("/pending", authorize("users:view:all"), listPendingUsersController);
usersRouter.post("/pending/:id/approve", authorize("users:view:all"), approvePendingUserController);
usersRouter.post("/pending/:id/decline", authorize("users:view:all"), declinePendingUserController);
usersRouter.patch("/:id/role", authorize("users:view:all"), changeUserRoleController);
