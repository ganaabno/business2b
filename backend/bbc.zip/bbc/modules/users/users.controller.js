import { asyncHandler } from "../../shared/http/asyncHandler.js";
import { badRequest } from "../../shared/http/errors.js";
import { approvePendingUserService, changeUserRoleService, declinePendingUserService, listPendingUsersService, listUsersService, } from "./users.service.js";
function getParam(value) {
    const text = String(value || "").trim();
    if (!text) {
        throw badRequest("id is required");
    }
    return text;
}
function parseReason(body) {
    const payload = (body || {});
    const reason = payload.reason ? String(payload.reason).trim() : null;
    if (reason && reason.length > 500) {
        throw badRequest("reason must be 500 characters or fewer");
    }
    return reason;
}
function parseRole(body) {
    const payload = (body || {});
    const role = String(payload.role || "").trim().toLowerCase();
    if (!role) {
        throw badRequest("role is required");
    }
    const allowed = new Set([
        "user",
        "subcontractor",
        "provider",
        "agent",
        "manager",
        "admin",
        "superadmin",
    ]);
    if (!allowed.has(role)) {
        throw badRequest("role must be one of: user, subcontractor, provider, agent, manager, admin, superadmin");
    }
    return role;
}
export const listUsersController = asyncHandler(async (_req, res) => {
    const data = await listUsersService();
    res.json({ data });
});
export const listPendingUsersController = asyncHandler(async (_req, res) => {
    const data = await listPendingUsersService();
    res.json({ data });
});
export const approvePendingUserController = asyncHandler(async (req, res) => {
    const data = await approvePendingUserService(req.user, getParam(req.params.id), parseReason(req.body));
    res.json({ data });
});
export const declinePendingUserController = asyncHandler(async (req, res) => {
    const data = await declinePendingUserService(req.user, getParam(req.params.id), parseReason(req.body));
    res.json({ data });
});
export const changeUserRoleController = asyncHandler(async (req, res) => {
    const data = await changeUserRoleService(req.user, getParam(req.params.id), parseRole(req.body));
    res.json({ data });
});
