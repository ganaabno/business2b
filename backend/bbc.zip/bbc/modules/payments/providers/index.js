import { qpayAdapter } from "./qpay.adapter.js";
import { badRequest } from "../../../shared/http/errors.js";
export function getPaymentProviderAdapter(providerRaw) {
    const provider = providerRaw.trim().toLowerCase();
    if (!provider) {
        throw badRequest("Payment provider is required");
    }
    const adapters = {
        qpay: qpayAdapter,
    };
    const adapter = adapters[provider];
    if (!adapter) {
        throw badRequest(`Unsupported payment provider: ${provider}`);
    }
    return adapter;
}
